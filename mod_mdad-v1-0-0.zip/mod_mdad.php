<?php
/**
 * @package Joomla
 * @subpackage mdad
 * @copyright (C) 2013 Mardink Webdesign
 * @license GNU/GPL, 
 * MD Ad is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License 3
 * as published by the Free Software Foundation.

 * MD Ad is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

	// no direct access
	defined( '_JEXEC' ) or die( 'Restricted access' );
	require( JModuleHelper::getLayoutPath( 'mod_mdad' ) );

?>